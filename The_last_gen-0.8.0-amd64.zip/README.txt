README:

1. Installiere "The_last_gen-0.8.0-amd64.msi".
2. Auf dem Desktop auf "The_last_gen" rechtsklicken und als Administrator ausf�hren.
3. Oben links auf auf "Options" klicken.
4. in dem Untermenu auf Change IP klicken.
5. Dann geben sie in dem Textfeld "thelastgen.ddns.net" ein und klicken auf "Check!".
6. Zum einloggen brauchen sie kein Passwort. Geben sie nur einen Namen ein den sie benutzen wollen und klicken sie auf "Check!".